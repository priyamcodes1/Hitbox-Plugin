package itzglecni.customhitboxes.gui;

import net.minecraft.class_437;

public class ConfigScreenProvider {

    public static class_437 buildScreen(class_437 parent) {
        return new CustomConfigScreen(parent);
    }
}