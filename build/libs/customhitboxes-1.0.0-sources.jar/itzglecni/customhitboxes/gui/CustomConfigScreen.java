package itzglecni.customhitboxes.gui;

import itzglecni.customhitboxes.config.ConfigManager;
import itzglecni.customhitboxes.config.ModConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;

public class CustomConfigScreen extends class_437 {
    private enum Section {
        TOGGLES,
        WIDTH,
        COLORS
    }

    private static final int PANEL_BG_TOP = 0xD0172130;
    private static final int PANEL_BG_BOTTOM = 0xD00C131E;
    private static final int PANEL_BORDER = 0xB8546C88;
    private static final int ROW_BG = 0xB7253449;
    private static final int ROW_HOVER_BG = 0xD53A4E6D;
    private static final int ROW_GLOW = 0x606A8CB8;
    private static final int TEXT_PRIMARY = 0xFFF0F6FF;
    private static final int SWITCH_BG = 0xFF1A222E;
    private static final int SWITCH_OFF = 0xFFD85A5A;
    private static final int SWITCH_ON = 0xFF47C97A;
    private static final int SWITCH_BORDER = 0xFFC7D8EB;
    private static final int RESET_BG = 0xFF2A3442;
    private static final int RESET_HOVER_BG = 0xFF344254;
    private static final int RESET_BORDER = 0xFFBFD0E6;
    private static final int RESET_TEXT = 0xFFFF6A6A;
    private static final float MIN_WIDTH = 0.1f;
    private static final float MAX_WIDTH = 20.0f;
    private static final float DEFAULT_WIDTH = 2.5f;
    private static final String WIDTH_LIMIT_TEXT = "You can only set the values from 0.1 to 20!";

    private final class_437 parent;
    private final ModConfig working;

    private final List<class_4185> sectionButtons = new ArrayList<>();
    private final List<Object> sectionElements = new ArrayList<>();
    private final List<RowMeta> rowMetas = new ArrayList<>();
    private final List<ColorPreviewMeta> colorPreviewMetas = new ArrayList<>();
    private final List<ToggleVisualMeta> toggleVisualMetas = new ArrayList<>();
    private final List<ResetVisualMeta> resetVisualMetas = new ArrayList<>();
    private final Map<RowMeta, Float> hoverProgress = new HashMap<>();

    private Section section = Section.TOGGLES;
    private class_4185 saveButton;

    private class_342 hitboxWidthField;
    private class_342 nonPlayerWidthField;

    private String widthValidationError;
    private int sectionScroll;
    private int maxSectionScroll;

    public CustomConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Hitbox Plus"));
        this.parent = parent;
        this.working = ConfigManager.getConfig().copy();
    }

    @Override
    protected void method_25426() {
        method_37067();
        sectionButtons.clear();
        sectionElements.clear();
        rowMetas.clear();
        colorPreviewMetas.clear();
        toggleVisualMetas.clear();
        resetVisualMetas.clear();

        addTopTabs();
        addBottomButtons();
        rebuildSectionWidgets();
    }

    private void addTopTabs() {
        int tabY = 18;
        int gap = 6;
        int available = this.field_22789 - 80 - (gap * 2);
        int tabWidth = class_3532.method_15340(available / 3, 84, 144);
        int tabHeight = 20;
        int total = tabWidth * 3 + gap * 2;
        int startX = (this.field_22789 - total) / 2;

        addTabButton(startX, tabY, tabWidth, tabHeight, Section.TOGGLES, class_2561.method_43470("Toggles"));
        addTabButton(startX + tabWidth + gap, tabY, tabWidth, tabHeight, Section.WIDTH, class_2561.method_43470("Width"));
        addTabButton(startX + (tabWidth + gap) * 2, tabY, tabWidth, tabHeight, Section.COLORS, class_2561.method_43470("Colors"));
        updateTabButtonStates();
    }

    private void addTabButton(int x, int y, int w, int h, Section target, class_2561 label) {
        class_4185 tab = this.method_37063(class_4185.method_46430(label, b -> {
            this.section = target;
            this.sectionScroll = 0;
            rebuildSectionWidgets();
            updateTabButtonStates();
        }).method_46434(x, y, w, h).method_46431());
        sectionButtons.add(tab);
    }

    private void updateTabButtonStates() {
        for (int i = 0; i < sectionButtons.size(); i++) {
            class_4185 button = sectionButtons.get(i);
            Section current = Section.values()[i];
            button.field_22763 = this.section != current;
        }
    }

    private void addBottomButtons() {
        int y = this.field_22790 - 30;
        int buttonW = class_3532.method_15340((this.field_22789 - 40) / 3, 96, 160);
        int gap = 16;
        int total = buttonW * 2 + gap;
        int startX = (this.field_22789 - total) / 2;
        int cancelX = startX;
        int saveX = startX + buttonW + gap;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419())
            .method_46434(cancelX, y, buttonW, 20)
            .method_46431());

        saveButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Save & Close"), b -> saveAndClose())
            .method_46434(saveX, y, buttonW, 20)
            .method_46431());
    }

    private void rebuildSectionWidgets() {
        removeSectionWidgets();
        rowMetas.clear();
        colorPreviewMetas.clear();
        toggleVisualMetas.clear();
        resetVisualMetas.clear();

        switch (section) {
            case TOGGLES -> buildTogglesSection();
            case WIDTH -> buildWidthSection();
            case COLORS -> buildColorsSection();
        }

        validateWidthFields();
    }

    private void removeSectionWidgets() {
        for (Object element : sectionElements) {
            if (element instanceof net.minecraft.class_364 guiElement) {
                method_37066(guiElement);
            }
        }
        sectionElements.clear();
    }

    private <T extends net.minecraft.class_364 & net.minecraft.class_4068 & net.minecraft.class_6379> T addSectionWidget(T widget) {
        T added = this.method_37063(widget);
        sectionElements.add(added);
        return added;
    }

    private void buildTogglesSection() {
        int firstY = getSectionTop() + 2;
        int rowY = firstY - sectionScroll;
        int rowH = 22;
        int gap = 6;
        int rowCount = 13;

        addToggleRow(rowY, rowH, "Mod Enabled", "Master toggle for the whole mod.",
            () -> working.enabled, v -> working.enabled = v, true);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Config Hotkey", "Allow the O key to open this config screen instantly.",
            () -> working.openConfigHotkeyEnabled, v -> working.openConfigHotkeyEnabled = v, true);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Elytra Players Only", "Only show player hitboxes when that player has Elytra equipped.",
            () -> working.renderOnlyWhenElytraEquipped, v -> working.renderOnlyWhenElytraEquipped = v, false);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Render Projectiles", "Show hitboxes for projectiles like arrows, pearls, and wind charges.",
            () -> working.renderProjectiles, v -> working.renderProjectiles = v, true);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Players + Projectiles Only", "When ON, only players and projectiles show hitboxes; mobs/animals are hidden.",
            () -> working.renderEntities, v -> working.renderEntities = v, false);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Looking Direction Line", "Draw a line showing where each entity is facing.",
            () -> working.lookingDirection, v -> working.lookingDirection = v, true);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Remove Direction Arrow", "Hide the arrow tip and keep only the direction line.",
            () -> working.removeDirectionArrow, v -> working.removeDirectionArrow = v, false);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Forehead Line", "Show the small forehead level line on hitboxes.",
            () -> working.foreheadLine, v -> working.foreheadLine = v, true);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Self Hitbox", "Render your own hitbox.",
            () -> working.selfHitbox, v -> working.selfHitbox = v, true);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Hover Color", "Apply color to hitboxes when your crosshair is over a hittable target.",
            () -> working.hoverColorHitbox, v -> working.hoverColorHitbox = v, true);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Hurt Color", "To change the color of hitbox after hitting an entity, enable this option and set 'Hit Color' in the Colors tab.",
            () -> working.hitColorHitbox, v -> working.hitColorHitbox = v, true);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Hide Firework Hitbox", "Do not render hitboxes for fireworks.",
            () -> working.noFireworkHitbox, v -> working.noFireworkHitbox = v, false);
        rowY += rowH + gap;

        addToggleRow(rowY, rowH, "Hide Stuck Arrows", "Skip hitboxes for arrows that are stuck and no longer flying.",
            () -> working.noStuckArrows, v -> working.noStuckArrows = v, false);

        int contentBottom = firstY + rowCount * rowH + (rowCount - 1) * gap;
        maxSectionScroll = computeMaxScroll(firstY, contentBottom);
        sectionScroll = class_3532.method_15340(sectionScroll, 0, maxSectionScroll);
    }

    private void addToggleRow(int y, int h, String label, String description,
                              BooleanGetter getter, BooleanSetter setter, boolean defaultValue) {
        int panelX = getContentPanelX();
        int panelW = getContentPanelWidth();
        if (!isRectFullyInsideSection(panelX, y, panelW, h)) {
            return;
        }

        int controlGap = 6;
        int resetW = class_3532.method_15340(panelW / 8, 58, 84);
        int toggleW = class_3532.method_15340(panelW / 7, 72, 110);

        int resetX = panelX + panelW - resetW - 8;
        int toggleX = resetX - toggleW - controlGap;

        addSectionWidget(class_4185.method_46430(class_2561.method_43473(), b -> {
            setter.set(!getter.get());
        }).method_46434(toggleX, y + 2, toggleW, h - 4).method_46436(class_7919.method_47407(class_2561.method_43470(description))).method_46431());

        ToggleVisualMeta toggleMeta = new ToggleVisualMeta(toggleX, y + 2, toggleW, h - 4, getter);
        toggleVisualMetas.add(toggleMeta);

        class_4185 reset = addSectionWidget(class_4185.method_46430(class_2561.method_43473(), b -> {
            setter.set(defaultValue);
        }).method_46434(resetX, y + 2, resetW, h - 4).method_46436(class_7919.method_47407(class_2561.method_43470("Reset this option"))).method_46431());
        resetVisualMetas.add(new ResetVisualMeta(resetX, y + 2, resetW, h - 4, class_2561.method_43470("RESET"), reset));

        RowMeta row = new RowMeta(panelX, y, panelW, h, class_2561.method_43470(label), class_2561.method_43470(description));
        rowMetas.add(row);
        hoverProgress.put(row, 0.0f);
    }

    private void buildWidthSection() {
        int panelX = getContentPanelX();
        int panelW = getContentPanelWidth();
        int rowH = 28;

        int firstY = getSectionTop() + 26;
        int y1 = firstY;
        int y2 = y1 + rowH + 12;

        int resetW = class_3532.method_15340(panelW / 8, 54, 82);
        int fieldW = class_3532.method_15340(panelW / 4, 124, 220);
        int fieldX = panelX + panelW - (resetW + fieldW + 18);
        int resetX = panelX + panelW - resetW - 8;

        maxSectionScroll = 0;
        sectionScroll = 0;

        hitboxWidthField = createNumericField(fieldX, y1 + 3, fieldW, hToField(rowH), working.hitboxWidth, v -> working.hitboxWidth = v);
        addSectionWidget(hitboxWidthField);

        class_4185 reset1 = addSectionWidget(class_4185.method_46430(class_2561.method_43473(), b -> {
            hitboxWidthField.method_1852("2.5");
            validateWidthFields();
        }).method_46434(resetX, y1 + 3, resetW, hToField(rowH)).method_46436(class_7919.method_47407(class_2561.method_43470("Reset to 2.5"))).method_46431());
        resetVisualMetas.add(new ResetVisualMeta(resetX, y1 + 3, resetW, hToField(rowH), class_2561.method_43470("RESET"), reset1));

        nonPlayerWidthField = createNumericField(fieldX, y2 + 3, fieldW, hToField(rowH), working.nonPlayerHitboxWidth, v -> working.nonPlayerHitboxWidth = v);
        addSectionWidget(nonPlayerWidthField);

        class_4185 reset2 = addSectionWidget(class_4185.method_46430(class_2561.method_43473(), b -> {
            nonPlayerWidthField.method_1852("2.5");
            validateWidthFields();
        }).method_46434(resetX, y2 + 3, resetW, hToField(rowH)).method_46436(class_7919.method_47407(class_2561.method_43470("Reset to 2.5"))).method_46431());
        resetVisualMetas.add(new ResetVisualMeta(resetX, y2 + 3, resetW, hToField(rowH), class_2561.method_43470("RESET"), reset2));

        RowMeta row1 = new RowMeta(panelX, y1, panelW, rowH, class_2561.method_43470("Hitbox Width"), class_2561.method_43470("Adjust player hitbox width from 0.1 to 20.0 (2.5 is default)."));
        RowMeta row2 = new RowMeta(panelX, y2, panelW, rowH, class_2561.method_43470("Non-Player Hitbox Width"), class_2561.method_43470("Adjust non-player hitbox width from 0.1 to 20.0 (2.5 is default)."));
        rowMetas.add(row1);
        rowMetas.add(row2);
        hoverProgress.put(row1, 0.0f);
        hoverProgress.put(row2, 0.0f);
    }

    private class_342 createNumericField(int x, int y, int width, int height, float value, FloatSetter onValidValue) {
        class_342 field = new class_342(this.field_22793, x, y, width, height, class_2561.method_43470(""));
        field.method_1852(String.format(Locale.ROOT, "%.2f", value));
        field.method_1863(v -> {
            Float parsed = parseRange(v);
            if (parsed != null) {
                onValidValue.set(parsed);
            }
            validateWidthFields();
        });
        return field;
    }

    private void buildColorsSection() {
        int firstY = getSectionTop() + 2;
        int rowY = firstY - sectionScroll;
        int rowH = 24;
        int gap = 6;

        addColorRow(rowY, rowH, "Hitbox Main Color", "Main color used for regular hitboxes.",
            () -> working.hitboxMainColor, v -> working.hitboxMainColor = v,
            () -> working.rainbowMain, v -> working.rainbowMain = v,
            0xFFFFFF, false);
        rowY += rowH + gap;

        addColorRow(rowY, rowH, "Hover Color", "Color shown when your crosshair is over a valid target.",
            () -> working.hoverColor, v -> working.hoverColor = v,
            () -> working.rainbowHover, v -> working.rainbowHover = v,
            0x00FF00, false);
        rowY += rowH + gap;

        addColorRow(rowY, rowH, "Hit Color", "Color shown for a short time after real damage.",
            () -> working.hitColor, v -> working.hitColor = v,
            () -> working.rainbowHit, v -> working.rainbowHit = v,
            0xFF0000, false);
        rowY += rowH + gap;

        addColorRow(rowY, rowH, "Looking Direction Color", "Color of the looking direction line.",
            () -> working.lookingDirectionColor, v -> working.lookingDirectionColor = v,
            () -> working.rainbowLooking, v -> working.rainbowLooking = v,
            0x0000FF, false);
        rowY += rowH + gap;

        addColorRow(rowY, rowH, "Forehead Line Color", "Color of the forehead guide line.",
            () -> working.foreheadLineColor, v -> working.foreheadLineColor = v,
            () -> working.rainbowForehead, v -> working.rainbowForehead = v,
            0xFF0000, false);
        rowY += rowH + gap;

        addColorRow(rowY, rowH, "Projectiles Color", "Color used for projectile hitboxes only.",
            () -> working.projectilesColor, v -> working.projectilesColor = v,
            () -> working.rainbowProjectiles, v -> working.rainbowProjectiles = v,
            0xFFFF00, false);

        int contentBottom = firstY + 6 * rowH + 5 * gap;
        maxSectionScroll = computeMaxScroll(firstY, contentBottom);
        sectionScroll = class_3532.method_15340(sectionScroll, 0, maxSectionScroll);
    }

    private void addColorRow(int y, int h, String label, String description,
                             IntGetter colorGetter, IntSetter colorSetter,
                             BooleanGetter rainbowGetter, BooleanSetter rainbowSetter,
                             int defaultColor, boolean defaultRainbow) {
        int panelX = getContentPanelX();
        int panelW = getContentPanelWidth();
        if (!isRectFullyInsideSection(panelX, y, panelW, h)) {
            return;
        }

        int resetW = class_3532.method_15340(panelW / 8, 58, 84);
        int rainbowW = class_3532.method_15340(panelW / 5, 92, 132);
        int editW = class_3532.method_15340(panelW / 5, 90, 128);
        int previewW = class_3532.method_15340(panelW / 12, 20, 36);

        int resetX = panelX + panelW - resetW - 8;
        int rainbowX = resetX - rainbowW - 6;
        int editX = rainbowX - editW - 6;
        int previewX = editX - previewW - 6;

        colorPreviewMetas.add(new ColorPreviewMeta(previewX, y + 3, previewW, h - 6, colorGetter));

        class_4185 edit = addSectionWidget(class_4185.method_46430(colorButtonText(colorGetter.get()), b -> {
            this.field_22787.method_1507(new ColorPickerScreen(this, class_2561.method_43470(label), colorGetter.get(), color -> {
                colorSetter.set(color);
                b.method_25355(colorButtonText(color));
            }));
        }).method_46434(editX, y + 3, editW, h - 6).method_46436(class_7919.method_47407(class_2561.method_43470("Open RGB picker"))).method_46431());

        class_4185 rainbow = addSectionWidget(class_4185.method_46430(rainbowText(rainbowGetter.get()), b -> {
            rainbowSetter.set(!rainbowGetter.get());
            b.method_25355(rainbowText(rainbowGetter.get()));
        }).method_46434(rainbowX, y + 3, rainbowW, h - 6).method_46436(class_7919.method_47407(class_2561.method_43470("Toggle rainbow mode for this color"))).method_46431());

        class_4185 reset = addSectionWidget(class_4185.method_46430(class_2561.method_43473(), b -> {
            colorSetter.set(defaultColor);
            rainbowSetter.set(defaultRainbow);
            edit.method_25355(colorButtonText(colorGetter.get()));
            rainbow.method_25355(rainbowText(rainbowGetter.get()));
        }).method_46434(resetX, y + 3, resetW, h - 6).method_46436(class_7919.method_47407(class_2561.method_43470("Reset color and rainbow"))).method_46431());
        resetVisualMetas.add(new ResetVisualMeta(resetX, y + 3, resetW, h - 6, class_2561.method_43470("RESET"), reset));

        RowMeta row = new RowMeta(panelX, y, panelW, h, class_2561.method_43470(label), class_2561.method_43470(description));
        rowMetas.add(row);
        hoverProgress.put(row, 0.0f);
    }

    private void validateWidthFields() {
        if (saveButton == null) {
            return;
        }

        widthValidationError = null;
        if (section == Section.WIDTH) {
            Float player = parseRange(hitboxWidthField == null ? null : hitboxWidthField.method_1882());
            Float nonPlayer = parseRange(nonPlayerWidthField == null ? null : nonPlayerWidthField.method_1882());
            if (player == null || nonPlayer == null) {
                widthValidationError = WIDTH_LIMIT_TEXT;
            }
        }

        saveButton.field_22763 = widthValidationError == null;
    }

    private Float parseRange(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        try {
            float value = Float.parseFloat(text);
            if (value < MIN_WIDTH || value > MAX_WIDTH) {
                return null;
            }
            return value;
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    private void saveAndClose() {
        // If width fields are present, validate and commit them before saving.
        if (hitboxWidthField != null && nonPlayerWidthField != null) {
            Float player = parseRange(hitboxWidthField.method_1882());
            Float nonPlayer = parseRange(nonPlayerWidthField.method_1882());
            if (player == null || nonPlayer == null) {
                validateWidthFields();
                return;
            }
            working.hitboxWidth = player;
            working.nonPlayerHitboxWidth = nonPlayer;
        }

        ModConfig live = ConfigManager.getConfig();
        live.copyFrom(working);
        ConfigManager.save();
        method_25419();
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (isMouseInSectionArea(mouseX, mouseY) && maxSectionScroll > 0) {
            int step = getScrollStep();
            int wheel = (int) Math.signum(verticalAmount);
            if (wheel == 0) {
                return true;
            }
            int next = sectionScroll - (wheel * step);
            sectionScroll = class_3532.method_15340(next, 0, maxSectionScroll);
            rebuildSectionWidgets();
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Avoid calling Screen background blur here to prevent duplicate blur passes under modded render stacks.
        context.method_25296(0, 0, this.field_22789, this.field_22790, 0xB00E1623, 0xB0060A12);

        int panelX = getOuterPanelX();
        int panelY = getOuterPanelY();
        int panelW = getOuterPanelWidth();
        int panelH = getOuterPanelHeight();

        context.method_25296(panelX, panelY, panelX + panelW, panelY + panelH, PANEL_BG_TOP, PANEL_BG_BOTTOM);
        context.method_73198(panelX, panelY, panelW, panelH, PANEL_BORDER);

        for (RowMeta row : rowMetas) {
            if (!isRowVisible(row)) {
                continue;
            }
            boolean hovered = row.contains(mouseX, mouseY);
            float current = hoverProgress.getOrDefault(row, 0.0f);
            float target = hovered ? 1.0f : 0.0f;
            current += (target - current) * 0.24f;
            hoverProgress.put(row, current);

            int color = blendColor(ROW_BG, ROW_HOVER_BG, current);
            context.method_25294(row.x(), row.y(), row.x() + row.w(), row.y() + row.h(), color);
            context.method_73198(row.x(), row.y(), row.w(), row.h(), 0xB96E89AD);
            if (current > 0.03f) {
                int glow = withAlpha(ROW_GLOW, (int) (96 * current));
                context.method_73198(row.x(), row.y(), row.w(), row.h(), glow);
            }
        }

        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 10, TEXT_PRIMARY);

        if (section == Section.WIDTH && widthValidationError != null) {
            context.method_27534(this.field_22793, class_2561.method_43470(widthValidationError).method_27692(class_124.field_1061), this.field_22789 / 2, this.field_22790 - 42, 0xFFFF5555);
        }

        super.method_25394(context, mouseX, mouseY, delta);

        for (ToggleVisualMeta toggle : toggleVisualMetas) {
            if (!isRectVisible(toggle.x(), toggle.y(), toggle.w(), toggle.h())) {
                continue;
            }
            boolean enabled = toggle.getter().get();
            context.method_25294(toggle.x(), toggle.y(), toggle.x() + toggle.w(), toggle.y() + toggle.h(), SWITCH_BG);
            context.method_73198(toggle.x(), toggle.y(), toggle.w(), toggle.h(), SWITCH_BORDER);

            int indicatorW = (toggle.w() / 2) - 4;
            int indicatorX = enabled ? toggle.x() + toggle.w() - indicatorW - 2 : toggle.x() + 2;
            int indicatorColor = enabled ? SWITCH_ON : SWITCH_OFF;
            context.method_25294(indicatorX, toggle.y() + 2, indicatorX + indicatorW, toggle.y() + toggle.h() - 2, indicatorColor);

            class_2561 state = enabled ? class_2561.method_43470("YES") : class_2561.method_43470("NO");
            int textColor = 0xFFF6FBFF;
            int textY = toggle.y() + (toggle.h() - 8) / 2;
            context.method_27534(this.field_22793, state, toggle.x() + (toggle.w() / 2), textY, textColor);
        }

        for (ResetVisualMeta reset : resetVisualMetas) {
            if (!isRectVisible(reset.x(), reset.y(), reset.w(), reset.h())) {
                continue;
            }
            boolean hovered = reset.button().method_49606();
            int bg = hovered ? RESET_HOVER_BG : RESET_BG;
            context.method_25294(reset.x(), reset.y(), reset.x() + reset.w(), reset.y() + reset.h(), bg);
            context.method_73198(reset.x(), reset.y(), reset.w(), reset.h(), RESET_BORDER);
            int textY = reset.y() + (reset.h() - 8) / 2;
            context.method_27534(this.field_22793, reset.label(), reset.x() + (reset.w() / 2), textY, RESET_TEXT);
        }

        for (RowMeta row : rowMetas) {
            if (!isRowVisible(row)) {
                continue;
            }
            int labelY = row.y() + (row.h() - 8) / 2;
            context.method_27535(this.field_22793, row.label(), row.x() + 10, labelY, TEXT_PRIMARY);
        }

        for (ColorPreviewMeta preview : colorPreviewMetas) {
            if (!isRectVisible(preview.x(), preview.y(), preview.w(), preview.h())) {
                continue;
            }
            int color = 0xFF000000 | (preview.getter().get() & 0x00FFFFFF);
            context.method_25294(preview.x(), preview.y(), preview.x() + preview.w(), preview.y() + preview.h(), color);
            context.method_73198(preview.x(), preview.y(), preview.w(), preview.h(), 0xCCECF5FF);
        }

        for (RowMeta row : rowMetas) {
            if (!isRowVisible(row)) {
                continue;
            }
            if (row.contains(mouseX, mouseY)) {
                context.method_51438(this.field_22793, row.description(), mouseX, mouseY);
                break;
            }
        }

        if (maxSectionScroll > 0) {
            int top = getSectionTop();
            int bottom = getSectionBottom();
            int trackX = getContentPanelX() + getContentPanelWidth() + 2;
            int trackY = top;
            int trackH = bottom - top;
            int thumbH = Math.max(20, (int) (trackH * 0.28f));
            int thumbRange = Math.max(1, trackH - thumbH);
            int thumbY = trackY + (int) ((sectionScroll / (float) maxSectionScroll) * thumbRange);
            context.method_25294(trackX, trackY, trackX + 6, trackY + trackH, 0x6C243043);
            context.method_25294(trackX + 1, thumbY, trackX + 5, thumbY + thumbH, 0xD39DC7FF);
        }
    }

    private int computeMaxScroll(int contentStartY, int contentBottomY) {
        return Math.max(0, contentBottomY - getSectionBottom());
    }

    private int getScrollStep() {
        return switch (section) {
            case TOGGLES -> 28; // row height + gap
            case COLORS -> 30;  // row height + gap
            case WIDTH -> 40;
        };
    }

    private int getOuterPanelX() {
        return class_3532.method_15340(this.field_22789 / 24, 12, 28);
    }

    private int getOuterPanelY() {
        return 46;
    }

    private int getOuterPanelWidth() {
        return this.field_22789 - (getOuterPanelX() * 2);
    }

    private int getOuterPanelHeight() {
        return this.field_22790 - 94;
    }

    private int getContentPanelX() {
        return getOuterPanelX() + 8;
    }

    private int getContentPanelWidth() {
        return getOuterPanelWidth() - 16;
    }

    private int getSectionTop() {
        return 54;
    }

    private int getSectionBottom() {
        return this.field_22790 - 56;
    }

    private boolean isMouseInSectionArea(double mouseX, double mouseY) {
        int left = getContentPanelX();
        int right = left + getContentPanelWidth();
        return mouseX >= left && mouseX <= right && mouseY >= getSectionTop() && mouseY <= getSectionBottom();
    }

    private boolean isRowVisible(RowMeta row) {
        return isRectVisible(row.x(), row.y(), row.w(), row.h());
    }

    private boolean isRectVisible(int x, int y, int w, int h) {
        int top = getSectionTop();
        int bottom = getSectionBottom();
        int left = getContentPanelX();
        int right = left + getContentPanelWidth();
        return y + h >= top && y <= bottom && x + w >= left && x <= right;
    }

    private boolean isRectFullyInsideSection(int x, int y, int w, int h) {
        int top = getSectionTop();
        int bottom = getSectionBottom();
        int left = getContentPanelX();
        int right = left + getContentPanelWidth();
        return y >= top && (y + h) <= bottom && x >= left && (x + w) <= right;
    }

    private int blendColor(int from, int to, float t) {
        t = Math.max(0.0f, Math.min(1.0f, t));
        int a1 = (from >>> 24) & 0xFF;
        int r1 = (from >>> 16) & 0xFF;
        int g1 = (from >>> 8) & 0xFF;
        int b1 = from & 0xFF;
        int a2 = (to >>> 24) & 0xFF;
        int r2 = (to >>> 16) & 0xFF;
        int g2 = (to >>> 8) & 0xFF;
        int b2 = to & 0xFF;
        int a = (int) (a1 + (a2 - a1) * t);
        int r = (int) (r1 + (r2 - r1) * t);
        int g = (int) (g1 + (g2 - g1) * t);
        int b = (int) (b1 + (b2 - b1) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private int withAlpha(int color, int alpha) {
        int a = Math.max(0, Math.min(255, alpha));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    private int hToField(int rowHeight) {
        return rowHeight - 4;
    }

    private class_2561 rainbowText(boolean enabled) {
        return enabled
            ? class_2561.method_43470("Rainbow ON").method_27692(class_124.field_1060)
            : class_2561.method_43470("Rainbow OFF").method_27692(class_124.field_1061);
    }

    private class_2561 colorButtonText(int color) {
        return class_2561.method_43470(String.format(Locale.ROOT, "RGB #%06X", color & 0xFFFFFF));
    }

    private record RowMeta(int x, int y, int w, int h, class_2561 label, class_2561 description) {
        boolean contains(int mouseX, int mouseY) {
            return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
        }
    }

    private record ColorPreviewMeta(int x, int y, int w, int h, IntGetter getter) {
    }

    private record ToggleVisualMeta(int x, int y, int w, int h, BooleanGetter getter) {
    }

    private record ResetVisualMeta(int x, int y, int w, int h, class_2561 label, class_4185 button) {
    }

    @FunctionalInterface
    private interface BooleanGetter {
        boolean get();
    }

    @FunctionalInterface
    private interface BooleanSetter {
        void set(boolean value);
    }

    @FunctionalInterface
    private interface IntGetter {
        int get();
    }

    @FunctionalInterface
    private interface IntSetter {
        void set(int value);
    }

    @FunctionalInterface
    private interface FloatSetter {
        void set(float value);
    }
}
