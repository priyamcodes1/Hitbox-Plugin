package itzglecni.customhitboxes.gui;

import java.util.Locale;
import java.util.function.IntConsumer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ColorPickerScreen extends class_437 {
    private static final int MIN_PANEL_WIDTH = 272;
    private static final int MAX_PANEL_WIDTH = 360;
    private static final int MIN_PANEL_HEIGHT = 212;
    private static final int MAX_PANEL_HEIGHT = 252;

    private final class_437 parent;
    private final IntConsumer onSave;

    private int red;
    private int green;
    private int blue;

    public ColorPickerScreen(class_437 parent, class_2561 title, int startColor, IntConsumer onSave) {
        super(title);
        this.parent = parent;
        this.onSave = onSave;
        this.red = (startColor >> 16) & 0xFF;
        this.green = (startColor >> 8) & 0xFF;
        this.blue = startColor & 0xFF;
    }

    @Override
    protected void method_25426() {
        int panelWidth = getPanelWidth();
        int panelHeight = getPanelHeight();
        int panelX = (this.field_22789 - panelWidth) / 2;
        int panelY = (this.field_22790 - panelHeight) / 2;
        int sliderY = panelY + 32;

        method_37063(new RgbSlider(panelX + 20, sliderY, panelWidth - 40, 20, class_2561.method_43470("R"), red, value -> red = value));
        sliderY += 30;
        method_37063(new RgbSlider(panelX + 20, sliderY, panelWidth - 40, 20, class_2561.method_43470("G"), green, value -> green = value));
        sliderY += 30;
        method_37063(new RgbSlider(panelX + 20, sliderY, panelWidth - 40, 20, class_2561.method_43470("B"), blue, value -> blue = value));

        int buttonY = panelY + panelHeight - 30;
        int buttonWidth = class_3532.method_15340((panelWidth - 60) / 2, 106, 152);

        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), b -> method_25419())
            .method_46434(panelX + 20, buttonY, buttonWidth, 20)
            .method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Save Color"), b -> {
            onSave.accept(getColor());
            method_25419();
        }).method_46434(panelX + panelWidth - buttonWidth - 20, buttonY, buttonWidth, 20)
            .method_46431());
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xA0101218);

        int panelWidth = getPanelWidth();
        int panelHeight = getPanelHeight();
        int panelX = (this.field_22789 - panelWidth) / 2;
        int panelY = (this.field_22790 - panelHeight) / 2;

        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xCC1B1F2A);
        context.method_73198(panelX, panelY, panelWidth, panelHeight, 0xB36E88A8);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, panelY + 10, 0xFFFFFF);

        super.method_25394(context, mouseX, mouseY, delta);

        int preview = 0xFF000000 | getColor();
        int previewTop = panelY + panelHeight - 72;
        context.method_25294(panelX + 20, previewTop, panelX + panelWidth - 20, previewTop + 18, preview);
        context.method_73198(panelX + 20, previewTop, panelWidth - 40, 18, 0xCCE6F2FF);

        class_2561 code = class_2561.method_43470(String.format(Locale.ROOT, "#%06X", getColor())).method_27692(class_124.field_1075);
        context.method_27534(this.field_22793, code, this.field_22789 / 2, previewTop + 24, 0x66D9FF);
    }

    private int getColor() {
        return (red << 16) | (green << 8) | blue;
    }

    private int getPanelWidth() {
        return class_3532.method_15340(this.field_22789 - 40, MIN_PANEL_WIDTH, MAX_PANEL_WIDTH);
    }

    private int getPanelHeight() {
        return class_3532.method_15340(this.field_22790 - 40, MIN_PANEL_HEIGHT, MAX_PANEL_HEIGHT);
    }

    private static final class RgbSlider extends class_357 {
        private final String channelName;
        private final IntConsumer onChange;

        private RgbSlider(int x, int y, int width, int height, class_2561 label, int start, IntConsumer onChange) {
            super(x, y, width, height, class_2561.method_43473(), start / 255.0);
            this.channelName = label.getString();
            this.onChange = onChange;
            method_25346();
        }

        @Override
        protected void method_25346() {
            method_25355(class_2561.method_43470(channelName + ": " + getChannelValue()));
        }

        @Override
        protected void method_25344() {
            onChange.accept(getChannelValue());
            method_25346();
        }

        private int getChannelValue() {
            return (int) Math.round(this.field_22753 * 255.0);
        }
    }
}
