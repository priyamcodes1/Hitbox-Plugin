package itzglecni.customhitboxes;

import itzglecni.customhitboxes.config.ConfigManager;
import itzglecni.customhitboxes.gui.CustomConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_304.class_11900;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class CustomHitboxes implements ClientModInitializer {
    private static final class_11900 KEY_CATEGORY = class_11900.method_74698(class_2960.method_60655("customhitboxes", "main"));
    private static final String OPEN_GUI_KEY = "key.customhitboxes.open_config";

    private static class_304 openConfigKey;

    @Override
    public void onInitializeClient() {
        ConfigManager.load();
        openConfigKey = KeyBindingHelper.registerKeyBinding(new class_304(
            OPEN_GUI_KEY,
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_O,
            KEY_CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
        System.out.println("[Hitbox Plus] Initialized ItzGlecni's Client-Side Hitbox Rendering Engine v1.0.0.");
    }

    private void onClientTick(class_310 client) {
        while (openConfigKey.method_1436()) {
            if (!ConfigManager.getConfig().openConfigHotkeyEnabled) {
                continue;
            }

            client.method_1507(new CustomConfigScreen(client.field_1755));
        }
    }
}