package itzglecni.customhitboxes.mixin;

import itzglecni.customhitboxes.config.ConfigManager;
import itzglecni.customhitboxes.config.ModConfig;
import itzglecni.customhitboxes.tracker.HitTracker;
import net.minecraft.class_12155;
import net.minecraft.class_12179;
import net.minecraft.class_12180;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1671;
import net.minecraft.class_1676;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_12155.class)
public class EntityRenderManagerMixin {

    @Inject(method = "drawHitbox", at = @At("HEAD"), cancellable = true)
    private void onDrawHitbox(class_1297 entity, float tickDelta, boolean localServerEntity, CallbackInfo ci) {
        ModConfig config = ConfigManager.getConfig();

        if (!config.enabled) {
            return;
        }

        class_310 client = class_310.method_1551();
        class_1657 localPlayer = client.field_1724;

        if (!config.selfHitbox && entity == localPlayer) {
            ci.cancel();
            return;
        }

        if (!config.renderProjectiles && entity instanceof class_1676) {
            ci.cancel();
            return;
        }

        // When enabled, render hitboxes only for players and projectiles.
        if (config.renderEntities && !(entity instanceof class_1657) && !(entity instanceof class_1676)) {
            ci.cancel();
            return;
        }

        if (config.noFireworkHitbox && entity instanceof class_1671) {
            ci.cancel();
            return;
        }

        if (config.noStuckArrows && entity instanceof class_1665 ppe) {
            if (ppe.method_18798().method_1027() == 0) {
                ci.cancel();
                return;
            }
        }

        if (config.renderOnlyWhenElytraEquipped && entity instanceof class_1657 targetPlayer && targetPlayer != localPlayer) {
            if (!targetPlayer.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833)) {
                ci.cancel();
                return;
            }
        }

        // Confirm a hit only after the target is actually in hurt state.
        HitTracker.confirmDamageState(entity);

        int resolvedColor = config.rainbowMain? getRainbowColor() : config.hitboxMainColor;
        
        if (entity instanceof class_1676) {
            resolvedColor = config.rainbowProjectiles? getRainbowColor() : config.projectilesColor;
        }
        
        if (config.hoverColorHitbox && localPlayer != null && entity instanceof class_1657) {
            class_239 crosshairTarget = client.field_1765;
            if (crosshairTarget != null && crosshairTarget.method_17783() == class_239.class_240.field_1331) {
                class_3966 entityHitResult = (class_3966) crosshairTarget;
                if (entityHitResult.method_17782() == entity) {
                    if (localPlayer.method_5858(entity) <= 9.0) {
                        resolvedColor = config.rainbowHover ? getRainbowColor() : config.hoverColor;
                    }
                }
            }
        }

        if (config.hitColorHitbox && entity instanceof class_1657 && HitTracker.wasRecentlyHit(entity.method_5628())) {
            resolvedColor = config.rainbowHit ? getRainbowColor() : config.hitColor;
        }

        float lineWidth = entity instanceof class_1657 ? config.hitboxWidth : config.nonPlayerHitboxWidth;
        int argbColor = withFullAlpha(resolvedColor);
        class_238 box = getLerpedBox(entity, tickDelta);

        class_12180.method_75541(box, class_12179.method_75536(argbColor, lineWidth));

        if (config.lookingDirection) {
            int dirColor = config.rainbowLooking? getRainbowColor() : config.lookingDirectionColor;
            int dirArgb = withFullAlpha(dirColor);
            class_243 lookVec = entity.method_5828(tickDelta);
            class_243 basePos = entity.method_30950(tickDelta);
            float eyeHeight = entity.method_5751();
            float length = 2.0f;
            class_243 start = basePos.method_1031(0.0, eyeHeight, 0.0);
            class_243 end = start.method_1019(lookVec.method_1021(length));

            if (!config.removeDirectionArrow) {
                class_12180.method_75556(start, end, dirArgb, lineWidth);
            } else {
                class_12180.method_75546(start, end, dirArgb, lineWidth);
            }
        }

        if (config.foreheadLine && entity instanceof class_1309) {
            int foreColor = config.rainbowForehead? getRainbowColor() : config.foreheadLineColor;
            int foreArgb = withFullAlpha(foreColor);
            float eyeHeight = entity.method_5751();
            class_243 basePos = entity.method_30950(tickDelta);
            double y = basePos.field_1351 + eyeHeight;
            class_238 foreheadBox = new class_238(box.field_1323, y - 0.01f, box.field_1321, box.field_1320, y + 0.01f, box.field_1324);
            class_12180.method_75541(foreheadBox, class_12179.method_75536(foreArgb, lineWidth));
        }

        ci.cancel();
    }

    private static class_238 getLerpedBox(class_1297 entity, float tickDelta) {
        class_238 base = entity.method_5829();
        class_243 lerpedPos = entity.method_30950(tickDelta);
        class_243 posDelta = lerpedPos.method_1023(entity.method_23317(), entity.method_23318(), entity.method_23321());
        return base.method_989(posDelta.field_1352, posDelta.field_1351, posDelta.field_1350);
    }

    private static int withFullAlpha(int rgb) {
        return 0xFF000000 | (rgb & 0x00FFFFFF);
    }

    private static int getRainbowColor() {
        float hue = (System.currentTimeMillis() % 2000L) / 2000f;
        return java.awt.Color.HSBtoRGB(hue, 1.0f, 1.0f);
    }
}