package itzglecni.customhitboxes.mixin;

import itzglecni.customhitboxes.tracker.HitTracker;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {

    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void onAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        if (target != null) {
            HitTracker.recordAttackAttempt(target.method_5628());
        }
    }
}