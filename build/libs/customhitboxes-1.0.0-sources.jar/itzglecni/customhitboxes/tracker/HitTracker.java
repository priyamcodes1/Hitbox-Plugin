package itzglecni.customhitboxes.tracker;

import net.minecraft.class_1297;
import net.minecraft.class_1309;

public class HitTracker {
    private static final long ATTACK_CONFIRMATION_WINDOW_MS = 900;
    private static final long HIT_HIGHLIGHT_DURATION_MS = 1000;

    private static int lastAttackedEntityId = -1;
    private static long lastAttackTimestamp = 0L;

    private static int lastConfirmedHitEntityId = -1;
    private static long lastConfirmedHitTimestamp = 0L;

    public static void recordAttackAttempt(int entityId) {
        lastAttackedEntityId = entityId;
        lastAttackTimestamp = System.currentTimeMillis();
    }

    public static void confirmDamageState(class_1297 entity) {
        if (!(entity instanceof class_1309 living)) {
            return;
        }

        long now = System.currentTimeMillis();
        if (entity.method_5628() != lastAttackedEntityId) {
            return;
        }

        if ((now - lastAttackTimestamp) > ATTACK_CONFIRMATION_WINDOW_MS) {
            return;
        }

        if (living.field_6235 > 0) {
            lastConfirmedHitEntityId = entity.method_5628();
            lastConfirmedHitTimestamp = now;
        }
    }

    public static boolean wasRecentlyHit(int entityId) {
        if (entityId == lastConfirmedHitEntityId) {
            return (System.currentTimeMillis() - lastConfirmedHitTimestamp) <= HIT_HIGHLIGHT_DURATION_MS;
        }
        return false;
    }
}